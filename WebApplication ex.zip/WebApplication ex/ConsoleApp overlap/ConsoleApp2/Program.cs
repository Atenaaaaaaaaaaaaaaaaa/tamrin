﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    public class Interval
    {
        public int Start;
        public int End;

        public Interval(int start, int end)
        {
            Start = start;
            End = end;
        }

        public override string ToString()
        {
            return $"[{Start}, {End}]";
        }
    }

    static void Main()
    {
        Console.Write("چند بازه می‌خوای وارد کنی؟ ");
        int n = int.Parse(Console.ReadLine());

        List<Interval> intervals = new List<Interval>();

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"بازه {i + 1}:");

            Console.Write("  شروع: ");
            int start = int.Parse(Console.ReadLine());

            Console.Write("  پایان: ");
            int end = int.Parse(Console.ReadLine());

            intervals.Add(new Interval(start, end));
        }

        // مرتب‌سازی بر اساس نقطه شروع
        intervals = intervals.OrderBy(i => i.Start).ToList();

        List<Interval> merged = new List<Interval>();
        merged.Add(intervals[0]);

        for (int i = 1; i < intervals.Count; i++)
        {
            Interval last = merged.Last();
            Interval current = intervals[i];

            if (current.Start <= last.End) // هم‌پوشانی یا اتصال
            {
                last.End = Math.Max(last.End, current.End);
            }
            else
            {
                merged.Add(current);
            }
        }

        Console.WriteLine("\n✅ بازه‌های ادغام‌شده:");
        foreach (var item in merged)
        {
            Console.WriteLine(item.ToString());
        }
    }
}
