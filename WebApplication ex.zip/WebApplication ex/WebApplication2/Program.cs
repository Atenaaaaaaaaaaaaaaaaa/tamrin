using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// ????? ???? ????????? Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "MyAPI",
        Version = "v1",
        Description = "A simple example API",
    });
});

var app = builder.Build();

// ???? ???? Swagger ?? ???? ?????
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "MyAPI v1");
        c.RoutePrefix = string.Empty;
    });
}

// Dictionary ???? ???? ????? ???????
Dictionary<string, List<string>> ExDictionary = new Dictionary<string, List<string>>();

// ????? ???? ????? ????? ??????
app.MapGet("/", () => "Hi, the program is running");

// ?????? Ex ???? ?? name ???
app.MapPost("/save-ex/{name}/{ex}", (string name, string ex) =>
{
    if (!ExDictionary.ContainsKey(name))
    {
        ExDictionary[name] = new List<string>();
    }
    ExDictionary[name].Add(ex);
    return Results.Ok($"Ex for {name} saved: {ex}");
});

// ?????? ???? Ex?? ???? name
app.MapGet("/ex/{name}", (string name) =>
{
    if (ExDictionary.ContainsKey(name))
    {
        return Results.Ok(ExDictionary[name]);
    }
    else
    {
        return Results.NotFound($"No ex found for {name}");
    }
});

// ??????????? ?? Ex
app.MapPut("/ex/{name}/{oldEx}/{newEx}", (string name, string oldEx, string newEx) =>
{
    if (!ExDictionary.ContainsKey(name))
    {
        return Results.NotFound($"No ex found for {name}");
    }

    var list = ExDictionary[name];
    var index = list.IndexOf(oldEx);
    if (index == -1)
    {
        return Results.NotFound($"Ex '{oldEx}' not found for {name}");
    }

    list[index] = newEx;
    return Results.Ok($"Updated ex for {name}: '{oldEx}' -> '{newEx}'");
});

// ??? ?? Ex
app.MapDelete("/ex/{name}/{ex}", (string name, string ex) =>
{
    if (!ExDictionary.ContainsKey(name))
    {
        return Results.NotFound($"No ex found for {name}");
    }

    var removed = ExDictionary[name].Remove(ex);
    if (removed)
    {
        return Results.Ok($"Ex '{ex}' removed for {name}");
    }
    else
    {
        return Results.NotFound($"Ex '{ex}' not found for {name}");
    }
});

app.Run();
